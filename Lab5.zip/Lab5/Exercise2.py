email = input("Please, write your email address: ")
if "@" and "." in email:
  print("Thanks for your written!")
else:
    print("An email address has to contain '@' and '.' strings. Please try again!")